# banner detection > 2023-11-27 5:49pm
https://universe.roboflow.com/computer-vision-1oxpg/banner-detection-6dndi

Provided by a Roboflow user
License: CC BY 4.0

